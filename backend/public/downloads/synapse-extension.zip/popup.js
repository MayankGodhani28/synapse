// =============================================================
// Synapse — popup.js
// Handles authentication (login/register) and quick-note save
// =============================================================

const API_BASE = "http://localhost:5000";

// DOM Elements
const authView = document.getElementById("authView");
const captureView = document.getElementById("captureView");
const authTitle = document.getElementById("authTitle");
const authSubtitle = document.getElementById("authSubtitle");
const popupAuthForm = document.getElementById("popupAuthForm");
const nameGroup = document.getElementById("nameGroup");
const confirmPasswordGroup = document.getElementById("confirmPasswordGroup");
const authName = document.getElementById("authName");
const authEmail = document.getElementById("authEmail");
const authPassword = document.getElementById("authPassword");
const authConfirmPassword = document.getElementById("authConfirmPassword");
const authSubmitBtn = document.getElementById("authSubmitBtn");
const authTogglePrompt = document.getElementById("authTogglePrompt");
const authToggleBtn = document.getElementById("authToggleBtn");
const statusEl = document.getElementById("status");

const userEmailLabel = document.getElementById("userEmailLabel");
const activeScopeLabel = document.getElementById("activeScopeLabel");
const popupLogoutBtn = document.getElementById("popupLogoutBtn");
const noteEl = document.getElementById("note");
const saveBtn = document.getElementById("save");

let isRegisterMode = false;
let statusTimer = null;
let currentUser = null;

// Storage helper (supports chrome.storage.local and localStorage fallback)
async function getStorage(key) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    return new Promise((resolve) => {
      chrome.storage.local.get([key], (result) => resolve(result[key]));
    });
  }
  return localStorage.getItem(key);
}

async function setStorage(key, value) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    return new Promise((resolve) => {
      chrome.storage.local.set({ [key]: value }, resolve);
    });
  }
  localStorage.setItem(key, typeof value === 'string' ? value : JSON.stringify(value));
}

async function removeStorage(key) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    return new Promise((resolve) => {
      chrome.storage.local.remove([key], resolve);
    });
  }
  localStorage.removeItem(key);
}

// ── Initialize ───────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  setupListeners();
  await checkAuthSession();
});

async function checkAuthSession() {
  const storedUser = await getStorage("synapse_user");
  const storedToken = await getStorage("synapse_token");

  if (storedUser && storedToken) {
    currentUser = typeof storedUser === 'string' ? JSON.parse(storedUser) : storedUser;
    renderLoggedIn();
  } else {
    renderLoggedOut();
  }
}

function renderLoggedIn() {
  authView.style.display = "none";
  captureView.style.display = "flex";

  const email = currentUser.email || "user@example.com";
  userEmailLabel.textContent = email;
  activeScopeLabel.textContent = `extension(${email})`;
  setTimeout(() => noteEl.focus(), 100);
}

function renderLoggedOut() {
  captureView.style.display = "none";
  authView.style.display = "flex";
  setAuthMode(false);
}

function setAuthMode(register) {
  isRegisterMode = register;
  if (register) {
    authTitle.textContent = "Create Account";
    authSubtitle.textContent = "Get your personal Synapse memory vault";
    nameGroup.style.display = "flex";
    confirmPasswordGroup.style.display = "flex";
    authSubmitBtn.textContent = "Create Account";
    authTogglePrompt.textContent = "Already have an account?";
    authToggleBtn.textContent = "Sign In";
    authName.setAttribute("required", "required");
    authConfirmPassword.setAttribute("required", "required");
  } else {
    authTitle.textContent = "Sign in to Synapse";
    authSubtitle.textContent = "Connect your personal memory layer";
    nameGroup.style.display = "none";
    confirmPasswordGroup.style.display = "none";
    authSubmitBtn.textContent = "Sign In";
    authTogglePrompt.textContent = "Don't have an account?";
    authToggleBtn.textContent = "Create Account";
    authName.removeAttribute("required");
    authConfirmPassword.removeAttribute("required");
  }
}

// ── Event Listeners ──────────────────────────────────────────
function setupListeners() {
  // Toggle Auth Mode
  authToggleBtn.addEventListener("click", () => {
    setAuthMode(!isRegisterMode);
  });

  // Auth Form Submit
  popupAuthForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    showStatus(null);

    const email = authEmail.value.trim();
    const password = authPassword.value;

    if (isRegisterMode) {
      const name = authName.value.trim();
      const confirmPassword = authConfirmPassword.value;

      if (password !== confirmPassword) {
        showStatus("Passwords do not match.", "error");
        return;
      }
      if (password.length < 6) {
        showStatus("Password must be at least 6 characters.", "error");
        return;
      }

      authSubmitBtn.disabled = true;
      authSubmitBtn.textContent = "Creating...";

      try {
        const res = await fetch(`${API_BASE}/auth/register`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, email, password, confirmPassword })
        });
        const data = await res.json();

        if (!res.ok || !data.success) {
          showStatus(data.error || "Failed to create account", "error");
          return;
        }

        await setStorage("synapse_token", data.token);
        await setStorage("synapse_user", data.user);
        currentUser = data.user;
        showStatus("Account created!", "success");
        setTimeout(() => {
          showStatus(null);
          renderLoggedIn();
        }, 500);
      } catch (err) {
        showStatus("Cannot reach server at " + API_BASE, "error");
      } finally {
        authSubmitBtn.disabled = false;
        authSubmitBtn.textContent = "Create Account";
      }
    } else {
      authSubmitBtn.disabled = true;
      authSubmitBtn.textContent = "Signing In...";

      try {
        const res = await fetch(`${API_BASE}/auth/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password })
        });
        const data = await res.json();

        if (!res.ok || !data.success) {
          showStatus(data.error || "Invalid email or password", "error");
          return;
        }

        await setStorage("synapse_token", data.token);
        await setStorage("synapse_user", data.user);
        currentUser = data.user;
        showStatus("Signed in!", "success");
        setTimeout(() => {
          showStatus(null);
          renderLoggedIn();
        }, 500);
      } catch (err) {
        showStatus("Cannot reach server at " + API_BASE, "error");
      } finally {
        authSubmitBtn.disabled = false;
        authSubmitBtn.textContent = "Sign In";
      }
    }
  });

  // Logout
  popupLogoutBtn.addEventListener("click", async () => {
    await removeStorage("synapse_token");
    await removeStorage("synapse_user");
    currentUser = null;
    showStatus("Signed out", "info");
    setTimeout(() => {
      showStatus(null);
      renderLoggedOut();
    }, 400);
  });

  // Save Note
  saveBtn.addEventListener("click", async () => {
    const content = noteEl.value.trim();
    if (!content) {
      showStatus("Please enter content first.", "error");
      return;
    }

    if (!currentUser || !currentUser.email) {
      showStatus("Please sign in first.", "error");
      renderLoggedOut();
      return;
    }

    saveBtn.disabled = true;
    showStatus("Saving to vault...", "info");

    const user_id = `extension(${currentUser.email})`;
    const payload = {
      user_id,
      content,
      source_url: null,
      source_type: "note"
    };

    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ action: "save-to-synapse", payload }, (res) => {
        saveBtn.disabled = false;
        if (chrome.runtime.lastError || !res || !res.ok) {
          fallbackDirectSave(payload);
        } else {
          noteEl.value = "";
          showStatus("Saved to Synapse ✓", "success");
        }
      });
    } else {
      fallbackDirectSave(payload);
    }
  });

  // Keyboard shortcut Ctrl+Enter / Cmd+Enter
  noteEl.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
      saveBtn.click();
    }
  });
}

async function fallbackDirectSave(payload) {
  try {
    const res = await fetch(`${API_BASE}/memory/add`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    saveBtn.disabled = false;
    if (data.success) {
      noteEl.value = "";
      showStatus("Saved to Synapse ✓", "success");
    } else {
      showStatus(data.error || "Save failed", "error");
    }
  } catch (err) {
    saveBtn.disabled = false;
    showStatus("Failed to reach Synapse backend", "error");
  }
}

// ── Helpers ──────────────────────────────────────────────────
function showStatus(text, type = "info") {
  clearTimeout(statusTimer);

  if (!text) {
    statusEl.className = "status-banner";
    statusEl.textContent = "";
    return;
  }

  statusEl.textContent = text;
  statusEl.className = `status-banner visible ${type}`;

  if (type === "success") {
    statusTimer = setTimeout(() => {
      statusEl.className = "status-banner";
    }, 2400);
  }
}
